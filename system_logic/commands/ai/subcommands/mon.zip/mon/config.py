"""
MON Configuration Manager.
Menangani pemuatan konfigurasi dinamis (JSON) untuk Thresholds, UI Colors, dan Sentinel Rules.

Fitur:
- Auto-generate 'mon_config.json' jika belum ada.
- Fail-safe loading (kembali ke default jika JSON korup).
- Menyimpan parameter vital untuk OOM Killer (Sentinel).
"""

import json
import os
from pathlib import Path
from typing import Any, Dict

# Lokasi file config disamakan dengan lokasi script ini berada (ai/subcommands/mon/)
BASE_DIR = Path(__file__).parent.resolve()
CONFIG_FILE = BASE_DIR / "Z-mon_config.json"

# Lokasi Log Sentinel (ditaruh di user cache agar tidak mengotori source code)
LOG_DIR = Path.home() / ".cache" / "ai-term"
SENTINEL_LOG_FILE = LOG_DIR / "sentinel_guard.log"

# ==========================================================
# DEFAULT CONFIGURATION (TEMPLATE)
# ==========================================================
# Konfigurasi ini akan ditulis ke JSON jika file tidak ditemukan.
# Mengikuti spesifikasi Sentinel Fase 1-3 yang diminta Silvia.

DEFAULT_CONFIG: Dict[str, Any] = {
    "version": 5.0,

    # --- SENTINEL (OOM KILLER & GUARDIAN) ---
    "sentinel": {
        "enabled": True,
        "interval_seconds": 1.0,  # Cek setiap detik
        "log_path": str(SENTINEL_LOG_FILE),

        # Ambang Batas (Thresholds)
        "thresholds": {
            # Fase 1: Black Box Recording (Mulai mencatat ke SSD)
            "phase1_log": {
                "ram_pct": 87.0,
                "swap_pct": 50.0
            },
            # Fase 2: Visual Warning (Header Merah Berkedip)
            "phase2_warn": {
                "ram_pct": 90.0,
                "swap_pct": 78.0
            },
            # Fase 3: The Executioner (Kill Process)
            "phase3_kill": {
                "ram_pct": 90.0,      # Trigger Kill RAM
                "ram_hold_sec": 5,    # Tahan 5 detik sebelum eksekusi
                "swap_pct": 87.0      # Trigger Kill SWAP (Immediate)
            }
        },

        # Daftar Kebal Hukum (Immunity List)
        # Proses ini TIDAK BOLEH dibunuh oleh Sentinel.
        "whitelist": [
            "systemd", "init",
            "Xorg", "wayland", "kwin_wayland", "gnome-shell", "surfaceflinger",
            "dbus-daemon", "dbus-broker",
            "pipewire", "pulseaudio", "wireplumber",
            "NetworkManager", "wpa_supplicant",
            "sshd", "login", "bash", "fish", "zsh",
            "python", "python3", "ai-term",  # Diri sendiri
            "code", "dockerd", "containerd"  # Dev tools (Optional, bisa dihapus user)
        ],

        # Strategi Kill: 'largest_rss' (Kill yg makan RAM fisik terbesar)
        "kill_strategy": "largest_rss"
    },

    # --- UI & VISUALIZATION ---
    "ui": {
        "refresh_rate": 1.0,
        "show_disks": True,
        "compact_mode": False,

        # Batas Warna (Green -> Yellow -> Red)
        "limits": {
            "cpu_warn": 70,
            "cpu_crit": 90,
            "ram_warn": 80,
            "ram_crit": 90,
            "temp_warn": 70,
            "temp_crit": 85,
            "ping_warn": 50,
            "ping_crit": 150
        }
    },

    # --- COLLECTORS SETTINGS ---
    "collectors": {
        "ping_target": "google.com",
        "ping_interval": 2.0,
        "disk_history_window_months": 30
    }
}


# ==========================================================
# LOGIC LOAD & SAVE
# ==========================================================

def _ensure_log_dir():
    """Memastikan folder log untuk Sentinel tersedia."""
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass # Ignore permission errors

def save_config(data: Dict[str, Any]) -> None:
    """Menulis konfigurasi ke file JSON."""
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        print(f"[CONFIG] Gagal menyimpan config: {e}")

def load_config() -> Dict[str, Any]:
    """
    Memuat konfigurasi.
    1. Jika file tidak ada -> Buat baru dari DEFAULT_CONFIG.
    2. Jika file ada tapi rusak -> Return DEFAULT_CONFIG (Fail-safe).
    3. Jika file ada -> Return isinya.
    """
    _ensure_log_dir()

    if not CONFIG_FILE.exists():
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG

    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            user_config = json.load(f)

            # Merge dengan default untuk memastikan key baru tetap ada
            # (Simple shallow merge for top-level keys)
            merged = DEFAULT_CONFIG.copy()
            merged.update(user_config)
            return merged

    except (json.JSONDecodeError, Exception) as e:
        # Jangan crash aplikasi monitoring hanya karena config error
        # Cukup print error kecil (opsional) dan pakai default
        return DEFAULT_CONFIG

# Helper untuk mengambil value dengan aman (deep get)
def get_nested(data: Dict, keys: list, default=None):
    """
    Mengambil value dari nested dictionary dengan aman.
    Contoh: get_nested(cfg, ['sentinel', 'thresholds', 'phase1_log'], {})
    """
    curr = data
    for k in keys:
        if isinstance(curr, dict) and k in curr:
            curr = curr[k]
        else:
            return default
    return curr