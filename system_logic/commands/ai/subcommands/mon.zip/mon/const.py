"""
MON Constants - Path & Config Locations.
Single source of truth untuk lokasi file history dan config.
"""

from pathlib import Path

# History database path (atomic writes untuk data metrik harian)
try:
    from system_logic.core import MON_HISTORY_PATH
except ImportError:
    # Fallback jika common belum ada
    MON_HISTORY_PATH = Path.home() / ".config" / "ai-term" / "mon_history.json"