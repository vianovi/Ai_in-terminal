"""
MON Storage Engine (History Database) - FIXED VERSION.
Menangani penyimpanan metrik jangka panjang (Battery, Disk TBW, dll).

Fitur Utama:
- Atomic Writes: Mencegah korupsi data jika sistem crash saat menulis.
- Time Travel Logic: Algoritma pencarian baseline data (compare vs 30 days ago).
- Snapshotting: Memastikan hanya 1 data poin per hari per metrik (append-only logic).

FIXES:
- Replaced bare except with specific exception handlers
- Added proper error logging for debugging
- Improved type safety and validation
- Added safeguards for edge cases
- Better month calculation using dateutil-compatible logic
"""

import json
import os
import datetime as _dt
from typing import Optional, List, Dict, Any

from system_logic.terminal import ansi
from .const import MON_HISTORY_PATH

# ==========================================================
# 1. ATOMIC I/O ENGINE
# ==========================================================


def _ensure_history_dir() -> None:
    """Memastikan folder penyimpanan ada."""
    try:
        MON_HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    except (OSError, PermissionError) as e:
        print(f"[STORAGE] Warning: Cannot create history directory: {e}")


def _load_db() -> Dict[str, Any]:
    """
    Membaca database JSON.
    Fail-safe: Jika file korup/kosong, kembalikan dict kosong (jangan crash).
    """
    if not MON_HISTORY_PATH.exists():
        return {}

    try:
        content = MON_HISTORY_PATH.read_text(encoding="utf-8")
        if not content.strip():
            return {}
        return json.loads(content)
    except json.JSONDecodeError as e:
        print(f"[STORAGE] Warning: Corrupted JSON in history file: {e}")
        # Optional: Backup corrupted file
        try:
            backup_path = MON_HISTORY_PATH.with_suffix(".corrupted.bak")
            MON_HISTORY_PATH.rename(backup_path)
            print(f"[STORAGE] Corrupted file backed up to: {backup_path}")
        except (OSError, PermissionError):
            pass
        return {}
    except (OSError, IOError, UnicodeDecodeError) as e:
        print(f"[STORAGE] Warning: Cannot read history file: {e}")
        return {}


def _save_db_atomic(data: Dict[str, Any]) -> None:
    """
    Menulis database secara ATOMIC (Zero-Corruption).
    1. Tulis ke file .tmp
    2. Flush ke disk
    3. Rename .tmp ke file asli (Atomic Operation)
    """
    _ensure_history_dir()

    # File sementara di folder yang sama (agar os.replace atomic di filesystem yang sama)
    tmp_path = MON_HISTORY_PATH.with_suffix(".tmp")

    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            f.flush()
            os.fsync(f.fileno())  # Paksa OS menulis buffer ke disk fisik

        # Atomic swap
        os.replace(tmp_path, MON_HISTORY_PATH)
    except (OSError, IOError, PermissionError) as e:
        print(f"[STORAGE] Error: Failed to save history: {e}")
        # Hapus file sampah jika ada
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except (OSError, PermissionError):
                pass


# ==========================================================
# 2. SNAPSHOT LOGIC
# ==========================================================


def snapshot_metric(category: str, item_id: str, metric: str, value: float) -> bool:
    """
    Menyimpan snapshot harian.
    Hanya menyimpan jika data hari ini BELUM ada.

    Args:
        category: "battery", "disk", dll.
        item_id: Nama unik item (misal: "nvme0n1").
        metric: Nama metrik (misal: "health_pct").
        value: Nilai float.

    Returns:
        True jika data baru berhasil disimpan.
    """
    db = _load_db()
    today = _dt.date.today().isoformat()

    # Inisialisasi struktur dict jika belum ada (Safe Nested Set)
    if category not in db:
        db[category] = {}
    if item_id not in db[category]:
        db[category][item_id] = {}
    if metric not in db[category][item_id]:
        db[category][item_id][metric] = {}

    # Guard: Pastikan target adalah dict (antisipasi data lama korup)
    target_series = db[category][item_id][metric]
    if not isinstance(target_series, dict):
        target_series = {}
        db[category][item_id][metric] = target_series

    # Cek apakah hari ini sudah ada?
    if today in target_series:
        return False  # Sudah ada, skip (hemat write cycle SSD)

    # Simpan
    target_series[today] = value
    _save_db_atomic(db)
    return True


# ==========================================================
# 3. DATA RETRIEVAL & TIME TRAVEL
# ==========================================================


def _parse_iso_date(s: str) -> Optional[_dt.date]:
    """Parse ISO date string with validation."""
    try:
        stripped = (s or "").strip()
        if not stripped:
            return None
        return _dt.date.fromisoformat(stripped)
    except (ValueError, AttributeError):
        return None


def list_metric_dates(category: str, item_id: str, metric: str) -> List[str]:
    """Mengembalikan list tanggal (ISO sorted) yang tersedia untuk metrik tertentu."""
    db = _load_db()
    series = db.get(category, {}).get(item_id, {}).get(metric, {})
    if not isinstance(series, dict):
        return []

    # Filter hanya key yang valid tanggal
    valid_dates = [k for k in series.keys() if _parse_iso_date(k) is not None]
    return sorted(valid_dates)


def get_metric_value(
    category: str, item_id: str, metric: str, date_iso: str
) -> Optional[float]:
    """Mengambil nilai pada tanggal tertentu."""
    db = _load_db()
    try:
        val = db.get(category, {}).get(item_id, {}).get(metric, {}).get(date_iso)
        return float(val) if val is not None else None
    except (ValueError, TypeError):
        return None


def _months_ago(d: _dt.date, months: int) -> _dt.date:
    """
    Mengurangi bulan dengan aman (handling akhir bulan).
    Improved: Proper month/year calculation with day clamping.
    """
    m = int(max(0, months))
    year = d.year
    month = d.month

    # Calculate target month/year
    total_months = year * 12 + month - m
    if total_months <= 0:
        # Clamp to earliest possible date
        return _dt.date(1, 1, 1)

    target_year = total_months // 12
    target_month = total_months % 12
    if target_month == 0:
        target_month = 12
        target_year -= 1

    # Handle day overflow (e.g., Jan 31 -> Feb 28/29)
    # Get last day of target month
    if target_month == 12:
        next_month = _dt.date(target_year + 1, 1, 1)
    else:
        next_month = _dt.date(target_year, target_month + 1, 1)

    last_day = (next_month - _dt.timedelta(days=1)).day
    safe_day = min(d.day, last_day)

    return _dt.date(target_year, target_month, safe_day)


def _select_baseline_date(dates: List[str], window_months: int = 30) -> Optional[str]:
    """
    Memilih tanggal baseline otomatis.
    Strategi: Cari tanggal terlama yang masih masuk dalam 'window_months'.
    Jika tidak ada, pakai tanggal terlama absolut.
    """
    if not dates:
        return None

    today = _dt.date.today()
    if window_months > 0:
        limit_date = _months_ago(today, window_months)
        # Cari tanggal terlama yang >= limit_date
        candidates = []
        for s in dates:
            d = _parse_iso_date(s)
            if d and d >= limit_date:
                candidates.append(s)

        if candidates:
            return candidates[0]  # Yang terlama dalam window

    return dates[0]  # Fallback absolut terlama


def _nearest_date_on_or_before(dates: List[str], want_iso: str) -> Optional[str]:
    """Mencari tanggal yang paling mendekati (<=) target."""
    target = _parse_iso_date(want_iso)
    if not target or not dates:
        return None

    best_iso: Optional[str] = None
    best_date: Optional[_dt.date] = None

    for s in dates:
        d = _parse_iso_date(s)
        if not d:
            continue

        if d <= target:
            if best_date is None or d > best_date:
                best_date = d
                best_iso = s

    return best_iso


def get_prev_date(category: str, item_id: str, metric: str) -> Optional[str]:
    """Mendapatkan tanggal snapshot sebelum hari ini (untuk delta harian)."""
    dates = list_metric_dates(category, item_id, metric)
    if not dates:
        return None

    today = _dt.date.today().isoformat()
    # Jika data terakhir adalah hari ini, ambil index -2
    if dates[-1] == today:
        return dates[-2] if len(dates) >= 2 else None

    # Jika data terakhir bukan hari ini (belum snapshot), ambil yang terakhir
    return dates[-1]


# ==========================================================
# 4. UI HELPER (TEXT GENERATOR)
# ==========================================================


def get_comparison_text(
    category: str,
    item_id: str,
    metric: str,
    current: float,
    unit: str = "",
    ref_date: Optional[str] = None,
    window_months: int = 30,
) -> str:
    """
    Menghasilkan string perbandingan: "vs 30 days ago [2023-01-01]: 90 -> 80 (-10)"
    """
    dates = list_metric_dates(category, item_id, metric)
    if not dates:
        return ""

    # Tentukan baseline date
    chosen_iso: Optional[str] = None
    if ref_date:
        # User minta tanggal spesifik
        if ref_date in dates:
            chosen_iso = ref_date
        else:
            chosen_iso = _nearest_date_on_or_before(dates, ref_date)

    if not chosen_iso:
        # Auto select
        chosen_iso = _select_baseline_date(dates, window_months)

    if not chosen_iso:
        return ""

    today_iso = _dt.date.today().isoformat()
    if chosen_iso == today_iso:
        return f"{ansi.c_dim()}(mulai tracking hari ini){ansi.c_reset()}"

    old_val = get_metric_value(category, item_id, metric, chosen_iso)
    if old_val is None:
        return ""

    diff = current - old_val

    # Calculate days ago safely
    chosen_date = _parse_iso_date(chosen_iso)
    if chosen_date is None:
        return ""

    days_ago = (_dt.date.today() - chosen_date).days

    icon = "⚪"
    if diff > 0:
        icon = "📈+"
    elif diff < 0:
        icon = "📉"

    date_tag = f"[{chosen_iso}]"

    return (
        f"{ansi.c_dim()}vs {days_ago} hari lalu {date_tag}: "
        f"{old_val:.2f} -> {current:.2f} "
        f"({icon}{diff:+.2f}{unit}){ansi.c_reset()}"
    )


def pick_date_interactive(dates: List[str], title: str = "Pilih tanggal") -> Optional[str]:
    """
    Helper UI sederhana untuk memilih tanggal dari list.
    (Disimpan di storage.py karena sangat erat dengan data list dates).
    """
    if not dates:
        return None

    print(f"\n{ansi.c_bold()}{title}{ansi.c_reset()}")

    # Tampilkan max 20 terakhir agar tidak flooding
    show_dates = dates[-20:]
    offset = len(dates) - len(show_dates)

    if offset > 0:
        print(f"  ... ({offset} tanggal terlama disembunyikan)")

    for i, d in enumerate(show_dates, start=1 + offset):
        print(f"  {i:>2}. {d}")

    print(f"  {ansi.c_dim()}0. Batal{ansi.c_reset()}")

    try:
        raw = input(
            f"{ansi.c_cyan()}Pilih nomor{ansi.c_reset()} (0-{len(dates)}): "
        ).strip()
        if not raw or raw == "0":
            return None

        idx = int(raw)
        if 1 <= idx <= len(dates):
            return dates[idx - 1]
    except (ValueError, KeyboardInterrupt, EOFError):
        pass

    return None